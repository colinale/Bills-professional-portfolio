Hello and welcome to my portfolio. During this experience, I had so many challenges to come by, flex by far being the hardest part of it. I created this website to showcase my portfolio and the work that I will be completing throughout my journey during this bootcamp. I have noticed great improvements since our first challenge with my CSS and HTML skills, but I'm not perfcect yet. I have to reach out to my professor, TA's, tutors, and my advisor to get some assistance along the way. All of which have been helpful! You will see the first project I have completed so far on the portfolio website is the run-buddy module that we have working on for the pasdt 2 weeks. There is also a few filler backgrounds taking place until I get new projects to replace it with. Overall,  this week has been challenging, but it has also been very eventful as I have been learning so much. The challenges are also to thank because of how much they push me and make me stretch out my knowledge. 

Deployed Application: https://colinale.github.io/Professional-portfolio/
Github Repository: https://github.com/colinale/Professional-portfolio

Images: ![Screenshot of active Portfolio site](./assets/Images/first-page.png))
![Screenshot of active Portfolio site](./assets/Images/second-page.png))
![Screenshot of active Portfolio site](./assets/Images/third-page.png))